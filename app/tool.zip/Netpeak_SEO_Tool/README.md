# Netpeak SEO onpage checker
Netpeak SEO OnPage Checker for Chrome. An Extension which brings a lot of features, regarding SEO for each page.

## Chrome locales
Open the following: chrome://settings/languages